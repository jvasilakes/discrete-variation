Some scopes in the original data (raw/ folder) were not annotated with their connecting cue.
That is, the <ref/> tag is missing (see below), causing my processing script to fail. I went through and manually
add <ref/>s where needed, with a comment. E.g., `<ref COMMENTS="fix by Jake 27/1/2022" ID="-1" SRC="53"/>`

```
<W>This</W>
<cue ID="1" type="negation">
  <W>is</W>
  <W>n't</W>
</cue>
<xcope ID="8">
  <ref COMMENTS="" ID="13" SRC="1"/>
  <W>the</W>
  <W>best</W>
  <W>of</W>
  <W>his</W>
  <W>rhyming</W>
  <W>abilities</W>
</xcope>
```
